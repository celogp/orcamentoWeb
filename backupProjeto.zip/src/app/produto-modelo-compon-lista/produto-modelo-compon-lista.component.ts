import { Component, OnInit } from '@angular/core';
import { Table } from 'primeng/table';
import { ProdutoModeloComponEntity } from '../entidades/ProdutoModeloCompon/ProdutoModeloComponEntity';
import { ProdutoModeloComponLst } from '../entidades/ProdutoModeloCompon/ProdutoModeloComponLst';
import { produtoModeloComponService } from '../produto-modelo-compon/produto-modelo-compon.service';

@Component({
  selector: 'app-produto-modelo-compon-lista',
  templateUrl: './produto-modelo-compon-lista.component.html',
  styleUrls: ['./produto-modelo-compon-lista.component.css']
})
export class ProdutoModeloComponListaComponent implements OnInit {

  lstProdutoModeloCompon = new Array<ProdutoModeloComponLst>();
  isShowGrid: boolean = false;
  strFilter:string='';

  constructor(private _produtoModeloComponService : produtoModeloComponService) { }

  ngOnInit(): void {
    this.isShowGrid = true;
  }

  doShowGridChanged(): void {
    this.isShowGrid = (this.isShowGrid == true ? false : true);
  }  

  doClear(table: Table) {
    table.clear();
  }

  applyFilterGlobal() : string{
    return this.strFilter;
  }

  doSelecionarItem(ItemProdutoEntity: ProdutoModeloComponEntity) {
    this.doShowGridChanged();
  }  

  doAtualizarPesquisa() {
    this._produtoModeloComponService.doGetProdutosModeloCompon()
      .subscribe((response) => {
        this.lstProdutoModeloCompon = response.data;
      },
        (error) => {
          //console.log(error);
        },
        () => {
          //console.log('this complet');
        }
      );
  }  


}


