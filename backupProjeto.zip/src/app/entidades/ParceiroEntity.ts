export class ParceiroEntity{
    id: number=0;
    razao: string=""; 
    nome: string="";
    cnpj: string="";
    inscricao: string="";
    cpf: string="";
    identidade: string="";
    email: string="";
    sexoId: number=1;
    fone: string="";
    celular: string="";
    celularIsWhatsApp: boolean=false;
    contato: string="";
    foneContato: string="";
    celularContato: string="";
    celularContatoIsWhatsApp: boolean=false;
    localizacaoId:number=0;
}