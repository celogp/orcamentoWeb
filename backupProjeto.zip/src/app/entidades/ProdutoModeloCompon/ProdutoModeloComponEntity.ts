
export class ProdutoModeloComponEntity{
    id : number=0;
    nome : string = '';
    largura : number=0;
    comprimento : number=0;
    altura : number=0;
    espessura : number=0;
    produtoId : number = 0;
}