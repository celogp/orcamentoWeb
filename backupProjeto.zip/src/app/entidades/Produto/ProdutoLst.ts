import { ProdutoEntity } from "./ProdutoEntity";

export class ProdutoLst extends ProdutoEntity{
}