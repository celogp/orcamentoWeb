export class ProdutoTipoEntity{
    id : number=0;
    nome : string = '';
}