import { ParceiroEntity } from "./ParceiroEntity";

export class ParceiroLst extends ParceiroEntity{
    cep:string="";
    logradouro:string="";
    localidade:string="";
    bairro:string="";    
}