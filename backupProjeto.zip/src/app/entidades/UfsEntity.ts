export class UfEntity{
    id: number=0;
    nome: string=""; //maximo de 8
    sigla: string=""; //maximo de 100
}