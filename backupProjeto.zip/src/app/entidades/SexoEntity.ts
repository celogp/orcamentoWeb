export class SexoEntity{
    id: number=0;
    nome: string=""; 
    sigla: string="";
}