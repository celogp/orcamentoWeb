import { FinanceiroEntity } from "./FinanceiroEntity";

export class FinanceiroLst extends FinanceiroEntity{
    nomeParceiro:string="";
}