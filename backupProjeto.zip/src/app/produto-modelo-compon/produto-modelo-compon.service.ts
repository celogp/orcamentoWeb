import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CFG_URLAPI } from '../app.config';
import { ObjetoResposta } from '../response/objectResponse';

@Injectable({
  providedIn: 'root'
})
export class produtoModeloComponService {

  private ProdutoModeloComponenteUrl: string = CFG_URLAPI.ProdutoModeloComponenteUrl;
  private httpOptions = {
      headers:
          new HttpHeaders(
              { 'Content-Type': 'application/json; charset=UTF-8', 'Access-Control-Allow-Origin':'*'}), 
      params : new HttpParams()
  };

  
  constructor(private http: HttpClient) { }


  doGetProdutosModeloCompon(){
    return this.http.get<ObjetoResposta>(this.ProdutoModeloComponenteUrl + 'doObterTodos()');
  }
}
