import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-produto-modelo-compon',
  templateUrl: './produto-modelo-compon.component.html',
  styleUrls: ['./produto-modelo-compon.component.css']
})
export class ProdutoModeloComponComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
