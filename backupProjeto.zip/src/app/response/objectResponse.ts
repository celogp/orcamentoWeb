export class ObjetoResposta{
    data:any;
    mensagens: any;
}